#!/bin/bash

#Creamos la funcion de ayuda
function help {
	echo "///////////////////////////////////////////////////////"
	echo "AYUDA DEL SCRIPT $0"
	echo "///////////////////////////////////////////////////////"
	echo
	echo "************************************************************************************"
	echo "Uso: $0 argumento1 argumento2"
	echo "Uso: $0 [ORIGEN] [DESTINO]"
	echo "************************************************************************************"
	echo
	echo "************************************************************************************"
	echo "Descripcion:"
	echo "Este script realiza un respaldo de los archivos del directorio de origen"
	echo "al directorio de destino, se almacenan con el nombre prefijo de la carpeta de origen"
	echo "seguido de la fecha en formato ANSI (YYYYMMDD) y en formato comprimido tar.gz"
	echo "************************************************************************************"
	echo
	echo "************************************************************************************"
	echo "Parametros:"
	echo "'ORIGEN' Directorio de origen de donde se hara el respaldo"
	echo "'DESTINO' Directorio de destino donde se guarda el respaldo"
	echo "************************************************************************************"
	echo
	echo "************************************************************************************"
	echo "Opciones:"
	echo "Use: $0 -h para ingresar a la ayuda"
	echo "************************************************************************************"
	echo
	echo "************************************************************************************"
	echo "Ejemplos de Uso:"
	echo "$0 /var/log /backup_dir"
	echo "Este comando realizara una copia de backup del contenido en /var/log a /backup_dir"
	echo "El nombre del archivo quedara: var_log_bkp_20240714.tar.gz"
	echo "************************************************************************************"
}

#Condicional para verificar si ingresa a la ayuda, esta la muestre
if [[ $1 == "-h" ]]; then
	help
	exit 0 #Codigo (exito)
fi

#Condicional para verificar si fueron ingresados dos argumentos
if [[ $# -ne 2 ]]; then
	echo "[ERROR] Se requiere ingresar parametro de entrada y salida"
	help
	exit 1 #Codigo (error)
fi

#Definimos las variables $1(primer argumento de entrada),$2(segundo argumento de entrada)
ORIGEN=$1
DESTINO=$2

#Condicional para verificar la existencia de los directorios
if [[ ! -d "$ORIGEN" ]]; then
	echo "[ERROR]: El directorio de origen $ORIGEN no existe o no se encuentra montado"
	exit 1
fi

if [[ ! -d "$DESTINO" ]]; then
	echo "[ERROR]: El directorio de destino $DESTINO no existe o no se encuentra montado"
	exit 1
fi

#Obtenemos la fecha en formato YYYYMMDD
FECHA=$(date +%Y%m%d)

#Obtenemos el nombre base y modificamos para que se guarde como deseamos
ORIGEN_BASE=$(basename "$ORIGEN")
ORIGEN_PARENT=$(dirname "$ORIGEN")
ORIGEN_PARENT=${ORIGEN_PARENT:1}

#Creamos el nombre por defecto para el guardado
BACKUP_RESPALDO=${ORIGEN_PARENT}_${ORIGEN_BASE}_bkp_${FECHA}.tar.gz

#Creamos el archivo de respaldo
tar -czf "$DESTINO/$BACKUP_RESPALDO" -C "$ORIGEN" . #Creamos el nombre por defecto para el guardado

echo "El backup $BACKUP_RESPALDO fue respaldado correctamente en $DESTINO"
